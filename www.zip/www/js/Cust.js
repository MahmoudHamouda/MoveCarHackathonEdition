function showdata() 
{
    //                    Ajax Request 
    var name="Sheshtawy";
    var password="XXX";
    var mobile= "010 0609 5119";
    var dep="TSSO";
    var pinput="123";
    var pinput4="-";
    var pinput3="ي";
    var pinput2="ي";
    var pinput1="ي";
    var image= "images/homeButton.png";
    
    
                    
    .getElementById("name").setAttribute("placeholder", name);
    document.getElementById("password").setAttribute("placeholder", password);
    document.getElementById("mobile").setAttribute("placeholder", mobile);
    document.getElementById("department").setAttribute("placeholder", dep);
                    
    document.getElementById("pinput").setAttribute("placeholder", pinput);
    document.getElementById("pinput4").setAttribute("placeholder", pinput4);
    document.getElementById("pinput3").setAttribute("placeholder", pinput3);
    document.getElementById("pinput2").setAttribute("placeholder", pinput2);
    document.getElementById("pinput1").setAttribute("placeholder", pinput1);
                    
    document.getElementById("cameraicon").setAttribute("src", image);
}